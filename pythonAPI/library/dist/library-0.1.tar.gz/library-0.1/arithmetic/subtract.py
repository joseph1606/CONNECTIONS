def subtract(x, y):
    return x - y