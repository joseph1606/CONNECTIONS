from setuptools import setup, find_packages

setup(
    name='library',
    version='0.1',
    packages=find_packages(),
    description='A simple Python library for basic arithmetic operations',
    author='Andrew',
    author_email='',
)